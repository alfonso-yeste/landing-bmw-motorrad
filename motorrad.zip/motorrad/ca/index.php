<?php

include '../inc/global.php';
include '../inc/vehiculos.php';

$page_configs = array(
    'lang' => 'ca',
    'header_title' => 'Ofertes BMW',
    'css' => '../assets/css/',
    'scripts' => '../assets/js/',
    'img' => '../assets/img/ca/',
    'img_general' => '../assets/img/',
    'inc' => '../inc/',
    'meta_description' => 'Concessionari oficial BMW. Tota la gamma BMW a la teva disposició amb ofertes increïbles',
    'title' => 'Km0 i Gerència',
    'modal_title' => 'Estàs a un clic de la teva oferta',
    'form_top_title' => 'Aconsegueix el teu BMW al millor preu!',
    'form_top_cta' => 'Demana la teva oferta!',
    'form_middle_title' => 'Models BMW en oferta',
    'form_middle_cta' => 'Demanar oferta',
    'form_middle_cta_other' => 'Descobreix la Teva Oferta',
    'clock_title' => 'Entrega immediata',
    'clock_subtitle' => '¡Stock limitat!',
    'form_bottom_title' => '',
    'form_bottom_subtitle' => 'Preus vàlids fins al 30 de setembre del 2020',
    'form_bottom_cta' => 'Demana la teva oferta!',
    'footer' => '© Tots els drets reservats BMW MOTORRAD',
    'privacy' => 'Política de Privacitat',
    'form_name' => 'Nom i Cognoms',
    'form_email' => 'Correu Electrònic',
    'form_tel' => 'Telèfon',
    'form_model' => 'Selecciona el model',
    'form_privacy_start' => 'Accepto la ',
    'form_privacy_end' => ' política de privacitat',
    'form_cookies_start' => 'Accepto la ',
    'form_cookies_end' => ' política de cookies',
    'another_model' => 'Un altre model',
    'form_dealer' => 'Concessionari',
    'price_from' => 'Des de',
    'gift_title' => 'Emporta\'t una Armilla Cool Down de regal amb la teva compra!',
    'gift_desc' => 'Aquesta revolucionaria armilla funcional aprofita el principi d\'evaporació com a refrigeració. A l\'humitejar l\'armilla amb aigua, el sistema HyperKewl absorbeix la humitat i l\'emmagatzema fins a vuit hores per a reduir la temperatura d\'entre 6°C i 12°C pel que fa a la temperatura exterior.',
    'gift_button' => 'Descobreix més sobre ',
    'gift_button_text' => 'l\'Armilla Cool Down',
    'gift_link' => 'https://www.bmw-motorrad.es/es/accessories-and-parts/rider-equipment/ride/cool-down-vest.html',
    'gift_img' => 'chaleco.png',
    'gift_conditions' => '*Només per a clients inscrits en aquesta pàgina'
);

include '../inc/components/generic-landing.php';