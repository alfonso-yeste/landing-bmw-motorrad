<!DOCTYPE html>
<html lang="es">
<head>
    <script>
        dataLayer = [];
        dataLayer.push({
            'event': 'pageview',                     
            'pageType': 'landing', 
            'carBrand': 'bmw',        
            'carModel': 'generic',      
            'carVariant': 'none',      
            'pageVersion': 1,
            'pageLang': '<?= $page_configs['lang'] ?>'
        });
    </script>
    <?= GTM_HEAD ?>

    <meta charset="UTF-8">
    <title><?= $page_configs['header_title'] ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?= $page_configs['img_general'] ?>favicon.png" type="image/png">
    <meta name="description" content="<?= $page_configs['meta_description'] ?>">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="preload" href="https://fonts.googleapis.com/css?family=Oswald|Raleway:500:900&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald|Raleway:500:900&display=swap"></noscript>
    <link rel="stylesheet" href="<?= $page_configs['css'] ?>style.css">

    <script defer src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script defer src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script defer type="text/javascript" src="<?= $page_configs['scripts'] ?>script.js"></script>
    <script defer type="text/javascript" src="<?= $page_configs['scripts'] ?>lazysizes.min.js"></script>
</head>
<body>
<?= GTM_BODY ?>

<?php include $page_configs['inc'] . 'modal.php'; ?>

<nav class="navbar navbar-light bg-white transition fixed-top">
    <div class="container-fluid" style="max-width: 1400px">
        <img height="100" class="lazyload logo" data-src="<?= $page_configs['img_general'] ?>logo.png" alt="">
        <img height="70" class="lazyload logo logo-dealer" data-src="<?= $page_configs['img_general'] ?>pruna-logo.jpg" alt="">
<!--        <p class="logo logo-dealer m-0" style="font-size: 25px"><strong>Pruna Motor</strong></p>-->
    </div>
</nav>

<div id="cover" class="container-fluid p-0">
    <img width="100%" class="lazyload desktop" data-src="<?= $page_configs['img'] ?>cover.jpg" alt="Ofertas BMW">
    <img width="100%" class="lazyload mobile" data-src="<?= $page_configs['img'] ?>cover-mobile.jpg" alt="Ofertas BMW">
</div>

<div class="container-fluid text-white below-cover" style="background-color:#3A66AA;">
    <div class="row" style="padding:40px 16px">
        <div class="col-md-6 mx-auto text-white text-center align-self-center">
            <p class="m-0" style="font-size:1.75rem;"><b><?= $page_configs['form_top_title'] ?></b></p>
        </div>
        <div class="col-md-6 mx-auto text-white text-center">
        <button class="btn btn-lg bg-white text-uppercase p-4" style="color:#3A66AA;" data-toggle="modal" data-target="#exampleModal" page-type="form-top" car-model="generic" car-variant="none" lang="<?= $page_configs['lang'] ?>"><b><?= $page_configs['form_top_cta'] ?></b></button>
        </div>
    </div>
</div>
<br>

<div class="container bg-light" style="border-radius:15px">
    <div class="row">
        <div class="col text-center"><br><br>
            <h1><b><?= $page_configs['form_middle_title'] ?></b></h1>
        </div>
    </div>
    <div class="row">
        <?php
            $i = 0;
            foreach ($vehiculos[APP_NAME]['versions'] as $key => $version) {
                echo '<div class="col-md-4 text-center mt-4 mr-auto ml-auto">
                        <div class="model transition pb-3" page-type="form-middle" car-brand="' . APP_NAME . '" car-model="' . $version['name'] . '" car-variant="none" lang="' . $page_configs['lang'] . '">
                            <img width="100%" class="lazyload" data-src="' . $page_configs['img_general'] . $version['name'] . '.png" alt="' . $vehiculos[APP_NAME]['name'] . ' ' . $version['name'] . '">
                            <h2>' . APP_NAME . ' ' . $version['name'] . '</h2>
                            <p>TIN: ' . $version['tin'] . '</p>
                            <p>' . $page_configs['price_from'] . ' <span style="font-size:150%">' . $version['price'] . '</span> <svg id="infoModal" data-toggle="modal" data-target="#infoPrice" width="1.2em" height="1.2em" viewBox="0 0 16 16" class="bi bi-info-circle-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM8 5.5a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg></p><br>
                            <button class="btn green-box text-white text-uppercase p-2" data-toggle="modal" data-target="#exampleModal" onclick="onClickDivModal(this)" page-type="form-middle" car-brand="' . APP_NAME . '" car-model="' . strtolower($version['name']) . '" car-variant="none" lang="' . $page_configs['lang'] . '"><b>' . $page_configs['form_middle_cta'] . '</b></button>
                        </div>
                    </div>';
                echo '<div class="modal fade" id="infoPrice" tabindex="-1" aria-labelledby="infoPrice" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Condiciones financieras</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                '. $version['info'] .'
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>';
                $i++;
                if ($i == 5) break;
            }
        ?>
        <div class="col-md-4 text-center mt-4 mr-auto ml-auto">
            <div class="model transition pb-3" data-toggle="modal" data-target="#exampleModal" onclick="onClickDivModal(this)" page-type="form-middle" car-brand="<?= APP_NAME ?>" car-model="<?= $page_configs['another_model'] ?>" car-variant="none" lang="<?= $page_configs['lang'] ?>">
                <img width="100%" class="lazyload" data-src="<?= $page_configs['img'] ?>anotherModel.png" alt="BMW <?= $page_configs['another_model'] ?>"><br><br><br>
                <button class="btn green-box text-white text-uppercase p-2" page-type="form-middle" car-brand="<?= APP_NAME ?>" car-model="<?= $page_configs['another_model'] ?>" car-variant="none" lang="<?= $page_configs['lang'] ?>"><b><?= $page_configs['form_middle_cta_other'] ?></b></button>
            </div>
        </div>
    </div>
    <br><br>
</div>
<br><br><br>

<div class="container-fluid">
    <div class="container text-center">
        <p style="font-size:2rem"><?= $page_configs['gift_title'] ?></p>
        <div class="row">
            <div class="col-lg-7 col-xs-12">
                <img class="lazyload p-5" data-src="<?= $page_configs['img_general'] . $page_configs['gift_img'] ?>" alt="<?= $page_configs['gift_title'] ?>" width="100%"/>
            </div>
            <div class="col-lg-5 col-xs-12 align-self-center">
                <div class="row">
                    <div class="col-md-12">
                        <p><?= $page_configs['gift_desc'] ?></p>
                        <!--                        <p>--><? //= $page_configs['gift_button'] ?><!--<a href="-->
                        <? //= $page_configs['gift_link'] ?><!--" target="_blank" rel="noopener noreferrer" style="color:#3a66aa">-->
                        <? //= $page_configs['gift_button_text'] ?><!--</a>.</p>-->
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 gift-conditions">
                        <small><?= $page_configs['gift_conditions'] ?></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container-fluid">
    <div class="row" style="background-color:#3A66AA;">
        <div class="col text-center text-white">
            <br><br>
            <h2><?= $page_configs['form_bottom_title'] ?></h2><br>
            <button class="btn btn-lg bg-white text-uppercase p-4" style="color:#3A66AA;" data-toggle="modal" data-target="#exampleModal" page-type="form-bottom" car-model="generic" car-variant="none" lang="<?= $page_configs['lang'] ?>" style="background-color: black"><b><?= $page_configs['form_bottom_cta'] ?></b></button>
            <br>
            <br>
            <p><?= $page_configs['form_bottom_subtitle'] ?></p>
            <br><br><br>
        </div>
    </div>
</div>

<div class="container-fluid bg-dark">
    <div class="container p-3 text-white">
        <div class="row">
            <div class="col">
                <?= $page_configs['footer'] ?>
            </div>
            <div class="col text-right">
                <a style="color:inherit;" href="<?= LOPD ?>" target="_blank" rel="noopener"><?= $page_configs['privacy'] ?></a>
            </div>
        </div>
    </div>
</div>
</body>
</html>