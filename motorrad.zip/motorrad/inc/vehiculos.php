<?php

$vehiculos = array(
    'BMW' => array(
        'name' => 'BMW',
        'versions' => array(
            'F 900 R' => array(
                'name' => 'F 900 R',
                'tin' => '4,99%',
                'price' => '150€/mes',
                'info' => 'P.V.P. Recomendado Península y Baleares para F 900 R: 8.995 € (transporte, descuentos e impuestos incluidos) para clientes que financien con BMW Bank GmbH, S.E. (según condiciones contractuales) con un plazo de 36 meses. IVA e impuesto de matriculación (IEDMT) calculado al tipo general. Gastos de matriculación y pre-entrega no incluidos. Ello no obstante, el tipo aplicable al IEDMT puede variar en función a la Comunidad Autónoma de residencia. Comisión de formalización 84,07 € al contado. Importe a financiar: 8.491,66 €. Precio total a plazos 10.035,15 €. Importe total adeudado 9.531,82 €. TIN 4,99 %. Valor futuro garantizado 4.047,75 € (36 meses y 30.000km). A los 3 años, podrás cambiarlo, devolverlo (según condiciones de contrato) o quedártelo pagando el valor final. Condiciones válidas hasta el 30/09/2020 y conforme a valoración crediticia. Financiación ofrecida por BMW Bank GmbH. S.E. Modelo mostrado puede no coincidir con el ofertado.',
            ),
            'F 900 XR 3' => array(
                'name' => 'F 900 XR',
                'tin' => '4,99%',
                'price' => '199€/mes',
                'info' => 'P.V.P. Recomendado Península y Baleares para F 900 XR: 11.950 € (transporte, descuentos e impuestos incluidos) para clientes que financien con BMW Bank GmbH, S.E. (según condiciones contractuales) con un plazo de 36 meses. IVA e impuesto de matriculación (IEDMT) calculado al tipo general. Gastos de matriculación y pre-entrega no incluidos. Ello no obstante, el tipo aplicable al IEDMT puede variar en función a la Comunidad Autónoma de residencia. Comisión de formalización 109,56 € al contado. Importe a financiar: 11.066,22 €. Precio total a plazos 13.295,84 €. Importe total adeudado 12.412,06 €. TIN 4,99 %. Valor futuro garantizado 5.138,50 € (36 meses y 30.000km). A los 3 años, podrás cambiarlo, devolverlo (según condiciones de contrato) o quedártelo pagando el valor final. Condiciones válidas hasta el 30/09/2020 y conforme a valoración crediticia. Financiación ofrecida por BMW Bank GmbH. S.E. Modelo mostrado puede no coincidir con el ofertado.'
            ),
            'R 1250 GS' => array(
                'name' => 'R 1250 GS',
                'tin' => '5,99%',
                'price' => '190€/mes',
                'info' => 'P.V.P. Recomendado Península y Baleares para R 1250 GS : 18.350,00 € (transporte, descuentos e impuestos incluidos) para clientes que financien con BMW Bank GmbH, S.E. (según condiciones contractuales) con un plazo de 36 meses. IVA e impuesto de matriculación (IEDMT) calculado al tipo general. Gastos de matriculación y pre-entrega no incluidos. Ello no obstante, el tipo aplicable al IEDMT puede variar en función a la Comunidad Autónoma de residencia. Comisión de formalización 127,14 € al contado. Importe a financiar: 12.842,34 €. Precio total a plazos 20.365,65 €. Importe total adeudado 14.857,99 €. TIN 5,99 %. Valor futuro garantizado 7.890,85 € (36 meses y 30.000km). A los 3 años, podrás cambiarlo, devolverlo (según condiciones de contrato) o quedártelo pagando el valor final. Condiciones válidas hasta el 30/09/2020 y conforme a valoración crediticia. Financiación ofrecida por BMW Bank GmbH. S.E. Modelo mostrado puede no coincidir con el ofertado.'
            ),
            'C 650 SPORT' => array(
                'name' => 'C 650 SPORT',
                'tin' => '4,99%',
                'price' => '140€/mes',
                'info' => 'P.V.P. Recomendado Península y Baleares para C 650 Sport: 9.612,13 € (transporte, descuentos e impuestos incluidos) para clientes que financien con BMW Bank GmbH, S.E. (según condiciones contractuales) con un plazo de 36 meses. IVA e impuesto de matriculación (IEDMT) calculado al tipo general. Gastos de matriculación y pre-entrega no incluidos. Ello no obstante, el tipo aplicable al IEDMT puede variar en función a la Comunidad Autónoma de residencia. Comisión de formalización 95,16 € al contado. Importe a financiar: 9.612,13 €. Precio total a plazos 10.871,39 €. Importe total adeudado 10.871,39 €. TIN 4,99 %. Valor futuro garantizado 5.736,23 € (36 meses y 30.000km). A los 3 años, podrás cambiarlo, devolverlo (según condiciones de contrato) o quedártelo pagando el valor final. Condiciones válidas hasta el 30/09/2020 y conforme a valoración crediticia. Financiación ofrecida por BMW Bank GmbH. S.E. Modelo mostrado puede no coincidir con el ofertado.'
            )
        )
    )
);