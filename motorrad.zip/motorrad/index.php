<?php

include './inc/global.php';
include './inc/vehiculos.php';

$page_configs = array(
    'lang' => 'es',
    'header_title' => 'Ofertas Pruna Motor Motorrad',
    'css' => './assets/css/',
    'scripts' => './assets/js/',
    'img' => './assets/img/es/',
    'img_general' => './assets/img/',
    'inc' => './inc/',
    'meta_description' => 'Concesionario oficial BMW. Toda la gama BMW a tu disposición con ofertas increíbles',
    'title' => 'Km0 y Gerencia',
    'modal_title' => 'Estás a un clic de conseguir tu oferta',
    'form_top_title' => '¡Consigue tu ' . APP_NAME . ' al mejor precio!',
    'form_top_cta' => '¡Pide tu oferta!',
    'form_middle_title' => 'Modelos BMW en oferta',
    'form_middle_cta' => 'Solicitar Oferta',
    'form_middle_cta_other' => 'Descubre tu Oferta',
    'clock_title' => 'Entrega inmediata',
    'clock_subtitle' => '¡Stock limitado!',
    'form_bottom_title' => '',
    'form_bottom_subtitle' => 'Precios válidos hasta el 30 de septiembre de 2020',
    'form_bottom_cta' => '¡Pide tu oferta!',
    'footer' => '© Todos los derechos reservados Pruna Motor',
    'privacy' => 'Política de Privacidad',
    'form_name' => 'Nombre y Apellidos',
    'form_email' => 'Correo Electrónico',
    'form_tel' => 'Teléfono',
    'form_model' => 'Selecciona tu modelo',
    'form_privacy_start' => 'Acepto la ',
    'form_privacy_end' => ' política de privacidad',
    'form_cookies_start' => 'Acepto la ',
    'form_cookies_end' => ' política de cookies',
    'another_model' => 'Otro Modelo',
    'form_dealer' => 'Concesionario',
    'price_from' => 'Desde',
    'gift_title' => '¡Llévate un Chaleco Cool Down de regalo con tu compra!*',
    'gift_desc' => 'Este revolucionario chaleco funcional aprovecha el principio de evaporación como refrigeración. Al humedecerse el chaleco con agua, el sistema HyperKewl absorbe la humedad y la almacena hasta ocho horas para reducir la temperatura de entre 6°C y 12°C con respecto a la temperatura exterior.',
    'gift_button' => 'Descubre más sobre ',
    'gift_button_text' => 'el Chaleco Cool Down',
    'gift_link' => 'https://www.bmw-motorrad.es/es/accessories-and-parts/rider-equipment/ride/cool-down-vest.html',
    'gift_img' => 'chaleco.png',
    'gift_conditions' => '*Para clientes registrados que compren una moto BMW antes del 30 de setiembre'
);

include 'inc/components/generic-landing.php';