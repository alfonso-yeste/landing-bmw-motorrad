$(document).ready(function(){
    //Scroll
    var $document = $(document),
        $element = $('.navbar'),
        className = 's-1';

    $document.scroll(function() {
        if ($document.scrollTop() >= 50) $element.addClass(className);
        else $element.removeClass(className);
    });

    $('#submit-form').click(e => {
        const email = $('input#email').val()
        const splitted = email.split('@')
        if (splitted.length != 2 || !splitted[1].includes('.')) {
            $('#form-error').text('Email inválido.');
            e.preventDefault();
        }
        else $('#form-error').text('');
    })

    $('#cover').css('margin-top', $('nav').outerHeight());
    $('#logo').bind('load', () => $('#cover').css('margin-top', $('nav').outerHeight()));
    window.onresize = () => $('#cover').css('margin-top', $('nav').outerHeight());
});

function onChangeModelSelection() {
    var selection = $('select#modelo').val();
    $('button#submit-form').attr('car-model', selection);
}

$('button').click(function () {
    //Datalayer
    var href = $(this).attr('href');
    var pageType = $(this).attr('page-type');
    var carModel = $(this).attr('car-model');
    var carVariant = $(this).attr('car-variant');
    var lang = $(this).attr('lang');

    $('#modelo').val(carModel.toUpperCase());

    if (pageType != 'form-submitted' || (pageType == 'form-submitted' && document.getElementById('form-cta').checkValidity())) {
        dataLayer.push({
            'event': 'gaEvent',
            'pageType': pageType,
            'carBrand': 'bmw',
            'carModel': carModel,
            'carVariant': carVariant,
            'pageVersion': 1,
            'pageLang': lang
        });
    }
});

function setModel(model) {
    $("select#modelo > option").each(function() {
        $(this).attr('selected', false);
    });
    $('select#modelo option[value="' + model +'"]').attr('selected', true);
}

function onClickDivModal(div) {
    var carModel = div.getAttribute('car-model');
    var carVariant = div.getAttribute('car-variant');

    //Salesforce
    setModel(carModel);

    //submit form button
    $('button#submit-form').attr('car-model', carModel);

    //To avoid pushing info to dataLayer twice make sure the div is being clicked and not the button inside the div which will be
    if (window.event.target.nodeName != 'BUTTON' && window.event.target.parentElement.nodeName != 'BUTTON') {
        var pageType = div.getAttribute('page-type');
        var lang = div.getAttribute('lang');

        dataLayer.push({
            'event': 'gaEvent',
            'pageType': pageType,
            'carBrand': 'bmw',
            'carModel': carModel,
            'carVariant': carVariant,
            'pageVersion': 1,
            'pageLang': lang
        });
    }
}